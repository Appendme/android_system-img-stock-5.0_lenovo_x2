package com.lenovo.launcher.theme.ribbon;

public final class R
{
  public static final class id
  {
    public static final int ll_widgetCityNameText = 2131427332;
    public static final int temperature_max = 2131427343;
    public static final int temperature_min = 2131427344;
    public static final int temperature_unit = 2131427345;
    public static final int weather_img = 2131427330;
    public static final int widgetAPMImage = 2131427340;
    public static final int widgetCityNameText = 2131427333;
    public static final int widgetColonImage = 2131427337;
    public static final int widgetDateText = 2131427342;
    public static final int widgetHour01Image = 2131427335;
    public static final int widgetHour02Image = 2131427336;
    public static final int widgetMinute01Image = 2131427338;
    public static final int widgetMinute02Image = 2131427339;
    public static final int widgetTimeLayout = 2131427334;
    public static final int widgetWeatherLayout = 2131427328;
    public static final int widgetWeatherText = 2131427331;
    public static final int widgetWeekText = 2131427341;
    public static final int widget_bg_2 = 2131427329;
  }

  public static final class drawable
  {
    
   public static final int lenweather_widget_bg = 2130837681;
    public static final int lenweather_widget_bg_cloudy = 2130837682;
    public static final int lenweather_widget_bg_default = 2130837683;
    public static final int lenweather_widget_bg_foggy = 2130837684;
    public static final int lenweather_widget_bg_rain = 2130837685;
    public static final int lenweather_widget_bg_sand = 2130837686;
    public static final int lenweather_widget_bg_smoke = 2130837687;
    public static final int lenweather_widget_bg_snow = 2130837688;
    public static final int lenweather_widget_bg_sunny = 2130837689;
    public static final int lenweather_widget_bg_thunder = 2130837690;
    public static final int lenweather_widget_bg_wind = 2130837691;
    public static final int lenweather_widget_colon = 2130837692;
    public static final int lenweather_widget_icon_big_rain = 2130837693;
    public static final int lenweather_widget_icon_big_snow = 2130837694;
    public static final int lenweather_widget_icon_cloudy = 2130837695;
    public static final int lenweather_widget_icon_cold = 2130837696;
    public static final int lenweather_widget_icon_fog = 2130837697;
    public static final int lenweather_widget_icon_free_rain = 2130837698;
    public static final int lenweather_widget_icon_haze = 2130837699;
    public static final int lenweather_widget_icon_hot = 2130837700;
    public static final int lenweather_widget_icon_ice_rain = 2130837701;
    public static final int lenweather_widget_icon_mid_cloud = 2130837702;
    public static final int lenweather_widget_icon_mid_rain = 2130837703;
    public static final int lenweather_widget_icon_mid_snow = 2130837704;
    public static final int lenweather_widget_icon_most_cloudy = 2130837705;
    public static final int lenweather_widget_icon_rain_snow = 2130837706;
    public static final int lenweather_widget_icon_small_rain = 2130837707;
    public static final int lenweather_widget_icon_small_snow = 2130837708;
    public static final int lenweather_widget_icon_smoke = 2130837709;
    public static final int lenweather_widget_icon_sunny = 2130837710;
    public static final int lenweather_widget_icon_sunny_cloudy = 2130837711;
    public static final int lenweather_widget_icon_thunder_rain = 2130837712;
    public static final int lenweather_widget_icon_wind = 2130837713;
    public static final int lenweather_widget_num_0 = 2130837714;
    public static final int lenweather_widget_num_1 = 2130837715;
    public static final int lenweather_widget_num_2 = 2130837716;
    public static final int lenweather_widget_num_3 = 2130837717;
    public static final int lenweather_widget_num_4 = 2130837718;
    public static final int lenweather_widget_num_5 = 2130837719;
    public static final int lenweather_widget_num_6 = 2130837720;
    public static final int lenweather_widget_num_7 = 2130837721;
    public static final int lenweather_widget_num_8 = 2130837722;
    public static final int lenweather_widget_num_9 = 2130837723;
    public static final int lenweather_widget_time_am = 2130837724;
    public static final int lenweather_widget_time_pm = 2130837725;
  }
}

/* Location:           D:\QQ\Users\378939353\FileRecv\Apk_Decomplier_ICS_1.0.2\projects\AliTheFox-3.0_20140404\AliTheFox-3.0_20140404_dex2jar.jar
 * Qualified Name:     com.lenovo.launcher.theme.alithefox.R
 * JD-Core Version:    0.6.0
 */