package com.lenovo.launcher.theme.davinci;

public final class R
{
	
  public static final class layout
  {
    public static final int weather_widget_provider = 2130903040;
  }
  
  public static final class id
  {
    public static final int temperature_max = 2131492878;
    public static final int temperature_min = 2131492879;
    public static final int temperature_unit = 2131492880;
    public static final int weather_img = 2131492875;
    public static final int widgetAPMImage = 2131492870;
    public static final int widgetCityNameText = 2131492877;
    public static final int widgetColonImage = 2131492867;
    public static final int widgetDateLayout = 2131492871;
    public static final int widgetDateText = 2131492872;
    public static final int widgetHour01Image = 2131492865;
    public static final int widgetHour02Image = 2131492866;
    public static final int widgetMinute01Image = 2131492868;
    public static final int widgetMinute02Image = 2131492869;
    public static final int widgetTimeLayout = 2131492864;
    public static final int widgetWeatherLayout = 2131492874;
    public static final int widgetWeatherText = 2131492881;
    public static final int widgetWeekText = 2131492873;
    public static final int widget_bg_2 = 2131492876;
  }

  public static final class drawable
  {
    public static final int lenweather_widget_bg_cloudy = 2130837921;
    public static final int lenweather_widget_bg_default = 2130837922;
    public static final int lenweather_widget_bg_foggy = 2130837923;
    public static final int lenweather_widget_bg_rain = 2130837924;
    public static final int lenweather_widget_bg_sand = 2130837925;
    public static final int lenweather_widget_bg_smoke = 2130837926;
    public static final int lenweather_widget_bg_snow = 2130837927;
    public static final int lenweather_widget_bg_sunny = 2130837928;
    public static final int lenweather_widget_bg_thunder = 2130837929;
    public static final int lenweather_widget_bg_wind = 2130837930;
    public static final int lenweather_widget_colon = 2130837931;
    public static final int lenweather_widget_icon_big_rain = 2130837932;
    public static final int lenweather_widget_icon_big_snow = 2130837933;
    public static final int lenweather_widget_icon_cloudy = 2130837934;
    public static final int lenweather_widget_icon_cold = 2130837935;
    public static final int lenweather_widget_icon_fog = 2130837936;
    public static final int lenweather_widget_icon_free_rain = 2130837937;
    public static final int lenweather_widget_icon_haze = 2130837938;
    public static final int lenweather_widget_icon_hot = 2130837939;
    public static final int lenweather_widget_icon_ice_rain = 2130837940;
    public static final int lenweather_widget_icon_mid_cloud = 2130837941;
    public static final int lenweather_widget_icon_mid_rain = 2130837942;
    public static final int lenweather_widget_icon_mid_snow = 2130837943;
    public static final int lenweather_widget_icon_most_cloudy = 2130837944;
    public static final int lenweather_widget_icon_rain_snow = 2130837945;
    public static final int lenweather_widget_icon_small_rain = 2130837946;
    public static final int lenweather_widget_icon_small_snow = 2130837947;
    public static final int lenweather_widget_icon_smoke = 2130837948;
    public static final int lenweather_widget_icon_sunny = 2130837949;
    public static final int lenweather_widget_icon_sunny_cloudy = 2130837950;
    public static final int lenweather_widget_icon_thunder_rain = 2130837951;
    public static final int lenweather_widget_icon_wind = 2130837952;
    public static final int lenweather_widget_num_0 = 2130837953;
    public static final int lenweather_widget_num_1 = 2130837954;
    public static final int lenweather_widget_num_2 = 2130837955;
    public static final int lenweather_widget_num_3 = 2130837956;
    public static final int lenweather_widget_num_4 = 2130837957;
    public static final int lenweather_widget_num_5 = 2130837958;
    public static final int lenweather_widget_num_6 = 2130837959;
    public static final int lenweather_widget_num_7 = 2130837960;
    public static final int lenweather_widget_num_8 = 2130837961;
    public static final int lenweather_widget_num_9 = 2130837962;
    public static final int lenweather_widget_time_am = 2130837963;
    public static final int lenweather_widget_time_pm = 2130837964;
  }
  
}